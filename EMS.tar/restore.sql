--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Employee Management System";
--
-- Name: Employee Management System; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Employee Management System" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_India.1252';


ALTER DATABASE "Employee Management System" OWNER TO postgres;

\connect -reuse-previous=on "dbname='Employee Management System'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Department; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Department" (
    "ID" integer NOT NULL,
    "Name" character varying(50) NOT NULL
);


ALTER TABLE public."Department" OWNER TO postgres;

--
-- Name: Employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Employee" (
    "ID" integer NOT NULL,
    "FirstName" character varying(30) NOT NULL,
    "LastName" character varying(30),
    "DeptId" integer NOT NULL,
    "Age" integer,
    "Email" character varying(40) NOT NULL,
    "Education" character varying(30),
    "Company" character varying(30),
    "Experience" integer,
    "Package" integer,
    "Gender" character varying(10)
);


ALTER TABLE public."Employee" OWNER TO postgres;

--
-- Name: Employee_ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Employee" ALTER COLUMN "ID" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Employee_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: Department; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Department" ("ID", "Name") FROM stdin;
\.
COPY public."Department" ("ID", "Name") FROM '$$PATH$$/4843.dat';

--
-- Data for Name: Employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Employee" ("ID", "FirstName", "LastName", "DeptId", "Age", "Email", "Education", "Company", "Experience", "Package", "Gender") FROM stdin;
\.
COPY public."Employee" ("ID", "FirstName", "LastName", "DeptId", "Age", "Email", "Education", "Company", "Experience", "Package", "Gender") FROM '$$PATH$$/4844.dat';

--
-- Name: Employee_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Employee_ID_seq"', 28, true);


--
-- Name: Department Department_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Department"
    ADD CONSTRAINT "Department_pkey" PRIMARY KEY ("ID");


--
-- Name: Employee EmailUnique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "EmailUnique" UNIQUE ("Email");


--
-- Name: Employee Employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "Employee_pkey" PRIMARY KEY ("ID");


--
-- Name: Employee Employee_Fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "Employee_Fkey" FOREIGN KEY ("DeptId") REFERENCES public."Department"("ID") NOT VALID;


--
-- PostgreSQL database dump complete
--

